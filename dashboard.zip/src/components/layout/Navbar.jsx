import './Navbar.scss'
import React from 'react'

const Navbar = () => {
	return (
		<div className="navbarMain">
			
		</div>
	)
}

export default Navbar
