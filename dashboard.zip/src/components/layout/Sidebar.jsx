import './Sidebar.scss'
import React from 'react'

const Sidebar = () => {
	return (
		<div className="sidebarMain">
			
		</div>
	)
}

export default Sidebar
