import React from 'react'

const Home = () => {
	return (
		<div>
			<h1>Page d'accueil</h1>	
		</div>
	)
}

export default Home
